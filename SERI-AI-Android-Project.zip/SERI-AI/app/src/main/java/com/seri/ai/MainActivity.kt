package com.seri.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var tts: TextToSpeech
    private val requestAudio = 41
    private val navy = Color.rgb(8, 13, 28)
    private val cyan = Color.rgb(72, 223, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(navy)
        }
        val title = TextView(this).apply {
            text = "S E R I   A I"
            textSize = 32f
            setTextColor(cyan)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "YOUR PERSONAL ASSISTANT"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "नमस्कार! मी SERI AI आहे."
            textSize = 18f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, 40, 0, 16)
        }
        heard = TextView(this).apply {
            text = "आदेश देण्यासाठी खालील बटण दाबा."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        }
        val listen = Button(this).apply {
            text = "🎤  बोला / Speak"
            textSize = 18f
            setOnClickListener { listen() }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(heard)
        root.addView(listen)
        setContentView(root)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts.language = Locale("mr", "IN")
    }

    private fun say(message: String) {
        status.text = message
        tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "seri_reply")
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "या फोनवर Speech Recognition उपलब्ध नाही."
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "mr-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "SERI AI ला आदेश द्या")
        }
        try { startActivityForResult(intent, 42) } catch (_: Exception) {
            status.text = "Voice input सुरू करता आले नाही."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) listen()
        else status.text = "Microphone permission आवश्यक आहे."
    }

    @Deprecated("Deprecated by Android, kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val command = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            heard.text = command
            handleCommand(command.lowercase(Locale.ROOT))
        }
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("youtube") || command.contains("यूट्यूब") -> openWeb("https://www.youtube.com", "YouTube उघडत आहे")
            command.contains("google") || command.contains("गुगल") -> openWeb("https://www.google.com", "Google उघडत आहे")
            command.contains("instagram") || command.contains("इन्स्टाग्राम") -> openWeb("https://www.instagram.com", "Instagram उघडत आहे")
            command.contains("वेळ") || command.contains("time") -> say("आत्ताची वेळ ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())} आहे")
            command.contains("कॉल") || command.contains("call") || command.contains("फोन") -> {
                say("फोन डायलर उघडत आहे")
                startActivity(Intent(Intent.ACTION_DIAL))
            }
            else -> say("हा आदेश अजून शिकवायचा आहे. कृपया दुसरा आदेश द्या.")
        }
    }

    private fun openWeb(url: String, message: String) {
        say(message)
        startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
