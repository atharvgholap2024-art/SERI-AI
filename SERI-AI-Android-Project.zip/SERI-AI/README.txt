SERI AI - Starter Android project

What this starter does:
- Opens as an Android app.
- Requests microphone permission and uses Android speech recognition (mr-IN).
- Speaks basic Marathi replies using Android Text-to-Speech.
- Opens YouTube, Google and Instagram in the browser/app.
- Opens the phone dialer (it does not place a call automatically).
- Tells the current time.

Important:
- This is a starter version, not a full phone-controlling AI.
- Speech recognition may require Google's speech services and internet.
- Android limits background listening and access to other apps. Sensitive actions need user confirmation.
- No OpenAI API key is included. AI chat and natural-language planning are not yet connected.

Build APK:
The included GitHub Actions workflow can build a debug APK after the project is uploaded to a GitHub repository. Open Actions > Build SERI AI APK > Run workflow, then download the SERI-AI-debug-apk artifact.
